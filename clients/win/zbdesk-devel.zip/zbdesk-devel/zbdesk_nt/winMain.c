/* noch ein versuch */
#define STRICT
#define _WIN32_WINNT 0x0400
#define _MT
#include <windows.h>
#include <winsock2.h>
#include <process.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include "resource.h" 


#define PORT 7010
#define DLOCK "<ZEIBERBUDE><STOP /></ZEIBERBUDE>"
#define DULOCK "<ZEIBERBUDE><START /></ZEIBERBUDE>"

int StartWinsock(void);

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK LowLevelKeyboardProc(INT nCode, WPARAM wParam, LPARAM lParam);
int parseCommand(const char *cmd);
void WindowThread(void *blub);
void LockScreen();
void UnlockScreen();
HHOOK lockHook=NULL;
const char *appName;
WNDCLASS wc;
HWND hWnd;
HWND hWndLock;
HWND root;
RECT rootRect;
MSG msg;
HANDLE thMut;
int locked;
unsigned long thId;
UINT nPreviousState;
OSVERSIONINFO  osvi;
char imgbuff[255];
HANDLE imgLogo;
HANDLE imgLock;
LPTSTR lockedRes = MAKEINTRESOURCE(IDB_BITMAP1);
LPTSTR logoRes = MAKEINTRESOURCE(IDB_BITMAP2);
LPTSTR appIco = MAKEINTRESOURCE(IDI_ICON1);


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR cmdLine, int cmdShow)
{
	// socket
	long rc;
	SOCKET acceptSock;
	SOCKET connSock;
	SOCKADDR_IN addr;
	char buff[256];
	const char *opt = "true";
	int ThreadNum = 1;
	thMut = CreateMutex(NULL,TRUE,NULL);
	locked = 0;
	
	sprintf(imgbuff,cmdLine);
	root = GetDesktopWindow();
	GetWindowRect(root,&rootRect);
	//window
	appName = "zbdesk";
	//wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra    =  0;
	wc.cbWndExtra    =  0;
	wc.hInstance = hInstance;
	wc.hCursor = LoadCursor(NULL,IDC_NO); //LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = LoadIcon(NULL, appIco);
	wc.hbrBackground = CreateSolidBrush(0x00996666);
	wc.lpszClassName = appName;
	wc.lpszMenuName = NULL;
	RegisterClass(&wc);

	
	// socket
	rc = StartWinsock();
	if(rc != 0)
	{
		return 1;
	}
	acceptSock = socket(AF_INET, SOCK_STREAM,0);
	if(acceptSock == INVALID_SOCKET)
		return 1;
	memset(&addr,0,sizeof(SOCKADDR_IN));
	addr.sin_family = AF_INET;
	addr.sin_port = htons(PORT);
	addr.sin_addr.s_addr = ADDR_ANY;
	setsockopt(acceptSock,SOL_SOCKET,SO_DONTLINGER,opt,strlen(opt));
	rc = bind(acceptSock,(SOCKADDR*)&addr,sizeof(SOCKADDR_IN));
	if(rc == SOCKET_ERROR)
		return 1;
	rc = listen(acceptSock,10);
	if(rc == SOCKET_ERROR)
		return 1;
	thId = _beginthread(WindowThread,0,&ThreadNum);
	while(1)
	{
		connSock = accept(acceptSock,NULL,NULL);
		if(connSock == INVALID_SOCKET)
			continue;
		rc = recv(connSock,buff,256,0);
		if(rc == 0)
		{
			continue;
		}
		if(rc == SOCKET_ERROR)
		{
			continue;
		}
		buff[rc] = '\0';
		parseCommand(buff);
		closesocket(connSock);
	}
	

	return 0;
}

int StartWinsock(void)
{
	WSADATA wsa;
	return WSAStartup(MAKEWORD(2,0),&wsa);
}

void WindowThread(void *blub)
{
	int isLock = 0;
	hWnd = CreateWindowEx(WS_EX_TOPMOST,appName,"zb1",
						WS_POPUP,
						rootRect.left,rootRect.top,rootRect.right,rootRect.bottom,
						NULL,NULL,wc.hInstance,NULL);
	hWndLock = CreateWindowEx(WS_EX_TOPMOST,appName,"zb2",
						WS_POPUP,
						(rootRect.right/2)-150,(rootRect.bottom/2)-100,
						300,200,
						hWnd,NULL,wc.hInstance,NULL);
	imgLogo = LoadBitmap(wc.hInstance,logoRes);
	imgLock = LoadBitmap(wc.hInstance,lockedRes);
											
	while(GetMessage(&msg,NULL,0,0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	RECT rc;
	const char logo[] = "sorry, this screen is locked";
	RECT rcLogo;
	char buffer[255];
	HBRUSH hBr;
	
	switch(msg)
		{
		case WM_DESTROY:
			{
				PostQuitMessage(0);
				return 0;
			}
		case WM_PAINT:
			{
				PAINTSTRUCT ps;
				HDC hDc;
				HBRUSH hBrush = CreateSolidBrush(0x00660000);
				HANDLE 	back_pic;
				GetWindowText(hWnd,buffer,5);
				if(strncmp(buffer,"zb1",3) == 0)
				{
					hDc = BeginPaint(hWnd,&ps);
					{
						back_pic = LoadImage(0,imgbuff,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);
						if(back_pic != NULL)
						{
							hBr = CreatePatternBrush(back_pic);
							FillRect(hDc,&rootRect,hBr);
						}
						// rechteck
						GetClientRect(hWnd,&rc);
						rc.bottom = rc.top + 30;
						FillRect(hDc,&rc,hBrush);
						// logo
						if(imgLogo != NULL)
						{
							hBr = CreatePatternBrush(imgLogo);
							rcLogo.left = rootRect.right-200;
							rcLogo.top = rootRect.top;
							rcLogo.right = rootRect.right;
							rcLogo.bottom = rootRect.top+30;
							FillRect(hDc,&rcLogo,hBr);
						}
					}
					EndPaint(hWnd,&ps);
				}
				else
				{
					hDc = BeginPaint(hWnd,&ps);
					{
						if(imgLock != NULL)
						{
							rcLogo.left = 0;// (rootRect.right / 2) - 150;
							rcLogo.right = 300; //rcLogo.left + 300;
							rcLogo.top = 0; //(rootRect.bottom / 2) - 100;
							rcLogo.bottom = 200; //rcLogo.top + 200;
							hBr = CreatePatternBrush(imgLock);
							FillRect(hDc,&rcLogo,hBr);
						}
					}
					EndPaint(hWnd,&ps);
				}
				return 0;
			}
		case WM_SHOWWINDOW:
			{
				if(wParam){
					if(lockHook == NULL)
					{
						lockHook = SetWindowsHookEx(WH_KEYBOARD_LL,(HOOKPROC)LowLevelKeyboardProc,wc.hInstance,0);
						SystemParametersInfo (SPI_SETSCREENSAVERRUNNING, TRUE, &nPreviousState, 0);
					}
				}
				else{
					if(lockHook != NULL)
					{
						UnhookWindowsHookEx(lockHook);
						SystemParametersInfo (SPI_SETSCREENSAVERRUNNING, TRUE, &nPreviousState, 0);
						lockHook = NULL;
					}
				}
			}
		}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}

LRESULT CALLBACK LowLevelKeyboardProc(INT nCode, WPARAM wParam, LPARAM lParam)
{
	return 1;
}

void LockScreen()
{
	ShowWindow(hWnd, SW_SHOW);
	UpdateWindow(hWnd);
	ShowWindow(hWndLock,SW_SHOW);
	UpdateWindow(hWndLock);
	SetForegroundWindow(hWndLock);
}

void UnlockScreen()
{
	ShowWindow(hWnd,SW_HIDE);
	UpdateWindow(hWnd);
	ShowWindow(hWndLock,SW_HIDE);
	UpdateWindow(hWndLock);
}

int parseCommand(const char *cmd){
	xmlDocPtr doc;
	xmlNodePtr cur;
	    
	doc = xmlParseMemory(cmd,strlen(cmd));
	if(doc == NULL)
		return(-1);
	cur = xmlDocGetRootElement(doc);
	if(cur == NULL){
		xmlFreeDoc(doc);
		return(-1);
	}
	if (xmlStrcmp(cur->name, (const xmlChar *) "ZEIBERBUDE"))
		return(-1);
	cur=cur->xmlChildrenNode;
	while(cur != NULL){
		if(!xmlStrcmp(cur->name, (const xmlChar *) "START")){
			UnlockScreen();
		}
		else if(!xmlStrcmp(cur->name, (const xmlChar *) "STOP")){
			LockScreen();
		}
		else if(!xmlStrcmp(cur->name, (const xmlChar *) "STATUS")){
			// status ausgeben
		}
		cur=cur->next;
	}
	return(0);
} 